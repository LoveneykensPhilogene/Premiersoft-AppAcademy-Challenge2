package ICandidatos;

public interface InterfaceCandidato {

	public void porcentagemDeCandidatos();

	public void mostrarIdadeMediaQA();

	public void mostrarCandidatoMaisVelhoIOS();

	public void mostrarCandidatoMaisNovoAPI_NET();

	public void mostrarSomaIdadeCandidatosAPI_NET();

	public void mostrarNumeroDeEstadosDistintos();
}
